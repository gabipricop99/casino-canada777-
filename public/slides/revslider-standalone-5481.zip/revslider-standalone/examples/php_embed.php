<?php include '../embed.php'; ?>
<!DOCTYPE html>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Revolution Slider Example - Embedding with PHP Method</title>
		<?php RevSliderEmbedder::headIncludes(); ?>
	</head>
	<body style="margin: 0; padding: 0">
		<?php RevSliderEmbedder::putRevSlider('example'); ?>
	</body>
</html>