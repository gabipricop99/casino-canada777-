<script type="text/javascript">
    var ajaxurl = '<?php echo site_url('c=admin&m=ajax'); ?>';
</script>
<?php echo apply_filters( 'visual_editor_before_body_end_filter', ''); ?>
</body>
</html>