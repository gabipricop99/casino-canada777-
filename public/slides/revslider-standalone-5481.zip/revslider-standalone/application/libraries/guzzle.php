<?php
if (!defined('BASEPATH')) { exit('No direct script access allowed'); }

class Guzzle
{
    public function __construct()
    {
        // require_once('vendor/autoload.php');
        require 'vendor/autoload.php';
    }
}